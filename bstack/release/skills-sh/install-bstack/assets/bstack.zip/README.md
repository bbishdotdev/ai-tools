# bstack

Version 0.7.0. bstack is the collection; Poteto Mode is one engineering skill within it. The package groups public engineering skills under `engineering/`, planning skills under `sdlc/`, and shared controls and writing skills under `shared/`. Principles and playbooks stay internal and load only when needed.

The local workspace app supports Wayfinder maps, accepted decisions, specs and Kanban tickets. The PR workflow provides a visual briefing, final overlap review, and optional GitHub publishing. Optional shared memory installs a separate user runtime from this bundle.

## Install

Python 3.11+ on macOS or Linux is required. Both routes install the same bundled package.

Setup adds the seven-rule [baseline](shared/references/baseline-agents.md) directly to managed blocks in `AGENTS.md` and, when Claude is selected, `CLAUDE.md`. It creates missing files and preserves existing project text and shared symlinks. The baseline applies with auto mode off. Add project-specific guidance outside the blocks; native tool init is optional and never runs automatically. Run `doctor` after an init to detect changed or missing blocks. Updates and uninstall touch only the owned blocks.

### With skills.sh

From the project where you want to use bstack, run:

```sh
npx skills add bbishdotdev/ai-tools --skill install-bstack
```

Choose your agent and project scope if prompted. Then open your agent in that project and ask:

> Use install-bstack to set up this project for my installed tools.

skills.sh downloads the installer skill; your agent runs it to install the full bundled package and check the result. Keep both the repository name and `--skill install-bstack` in the command. You don't need to select individual engineering or SDLC skills. Automatic routing stays opt-in.

### From a download or clone

[Download bstack](https://github.com/bbishdotdev/ai-tools/releases/latest), choose `bstack-<version>.zip`, and extract it. Ask your agent to read `SKILL.md` in the extracted folder and install bstack into your project. Or run there:

```sh
python3 install.py --project /path/to/my-project
```

From a clone or source archive, the same entrypoint is `bstack/release/skills-sh/install-bstack/install.py`. It installs the bundled package and runs `doctor` without Git, npm, skills.sh, or network access. Add `--hosts` followed by the tools you want to choose hosts. Without it, a new install configures all four and an upgrade preserves the existing selection.

If you already have this unpacked runtime package, its controller also supports direct installation:

```sh
python3 <package-path>/scripts/bstack.py install --project <project-root>
python3 <project-root>/.bstack/package/scripts/bstack.py doctor --project <project-root>
```

Installation creates `.bstack/package/` and direct public entries in `.agents/skills/`, with links for the selected hosts. The original source can be removed afterward.

A skills.sh distributor uses the separate `install-bstack` transport skill, whose archive contains this same package. Run that skill's installer after distribution. skills.sh does not run setup automatically.

## Use skills directly

Invoke `how`, `architect`, `tdd`, or another public skill by its native host command prefix. Codex uses `$how`; slash-command hosts use `/how`. Use `poteto-mode` when you want the router to select a complete engineering workflow. The [index](index.json) resolves internal dependencies; the [manifest](manifest.json) lists public skills and exact installed files.

Engineering and SDLC skills are explicit-only by default. The customized [unslop](shared/unslop/SKILL.md) remains active for prose. `bstack-auto on`, `off`, and `status` control optional automatic routing with the host's skill prefix. A bare invocation shows these choices without running a command. The same commands are available from the controller:

```sh
python3 <project-root>/.bstack/package/scripts/bstack.py auto on --project <project-root>
python3 <project-root>/.bstack/package/scripts/bstack.py doctor --project <project-root>
```

Start a fresh session after bindings change. Checking status or repeating an unchanged mode does not require a new session. Turning auto off cannot erase existing conversation context.

With automatic routing enabled for Codex, open `codex` in a terminal in the project directory and enter `/hooks` there to review hook trust. `/hooks` is not a desktop chat command. Setup does not grant or inspect trust, and `auto status` confirms configuration only. With auto off, no bstack routing hook review is needed. Cursor and Grok's after-tool reminders do not guarantee first-tool or tool-free delivery. CLI packaging does not establish desktop or native plugin-manager support.

## Local planning and tickets

```sh
python3 <package-path>/workspace/cli.py --project <project-root> init
python3 <package-path>/workspace/cli.py --project <project-root> serve
```

Open the printed local URL. Work stays in the owning Git project's ignored `.bstack/workspace/`; linked worktrees share the same store. The browser and agent CLI use the same records. See [workspace use](workspace/README.md) and [operations](workspace/OPERATIONS.md). Python and Git are required for the workspace; Node and network access are not required to run the compiled app.

Use `wayfinder` to organize unknowns, `to-spec` for accepted scope, and `to-tickets` for implementation slices. Known small work can start with a ticket. Planning does not start implementation. The `implement` entry revalidates approved work before entering the engineering process. `handoff` preserves current record revisions, authority and artifacts for a fresh session, including prototype-to-implementation transitions.

Manual planning needs no model setup. Explicit autonomous grilling requires two configured models and evidence that the host can run them; see [decision authority](shared/references/decision-authority.md). Wayfinder and tickets have [independent provider selections](shared/references/work-adapters.md). Both default to local. Jira, GitHub and Linear adapters remain future work; unsupported configured providers are reported without silent fallback.

## Pull requests

Use [to-pr](engineering/to-pr/SKILL.md) for authorized PR delivery. It reuses the completed implementation and review, produces a short visual briefing, and checks all open work for duplicate or conflicting intent. Flagged or incomplete reviews publish as drafts with linked notices.

The [template](github/pull_request_template.md) and [Python helper](github/pr.py) ship here. The helper uses authenticated `gh` for pushed branches within the same GitHub repository. It prepares locally, checks freshness, and writes only with explicit `publish --write`. Media upload falls back to the authored Mermaid, table, or text explanation. Other forges need a supported adapter; GitHub PR publishing does not implement the planning or ticket tracker adapters.

## Optional shared memory

Ask your agent: "Use setup-bstack to enable shared personal memory on this machine."

The [memory setup guide](shared/memory/references/installation.md) covers preview, activation, and existing installations. The commands are:

```sh
python3 <package-path>/scripts/bstack.py memory setup
python3 <package-path>/scripts/bstack.py memory setup --apply-plan <digest>
python3 <package-path>/scripts/bstack.py memory status
```

The first command only previews. Setup copies the reviewed runtime to `~/.local/share/bstack/memory/runtime/` and connects Codex, Claude, and Cursor's file bridge. The user-wide skill at `~/.agents/skills/memory-policy` owns later approved note operations. This private payload is not another project-level skill. Grok has no memory adapter.

Project setup and auto mode do not activate memory. Existing notes and unrelated configuration survive setup. Legacy source-linked memory installs are reported and left untouched. Setup status checks files and configuration; fresh-session recall needs a separate live check.

## Update and remove

Rerun the installer from a reviewed release to update. It preserves the chosen mode, verifies owned files, and refuses unowned or changed content. Existing offline Poteto Mode bundles migrate to the package layout. Old third-party distributor entries must be resolved through their owner if they collide.

Run the canonical controller with `uninstall --project <project-root>` to remove its verified package and owned bindings. Private work, workspace databases, role and adapter configuration, artifacts, and separately distributed installer skills are preserved. Install separately per checkout; generated absolute bindings are machine-specific.

User memory has a separate lifetime. Project updates and removal leave its runtime and notes intact. Explicitly rerun memory setup from a reviewed newer bundle to update that runtime.

## Dependencies and source

[Attribution and required notices](ATTRIBUTION.md) travel with the package. The manifest records source hashes and build transformations. [layers.json](layers.json) records the active replacements. Installation never follows upstream latest.

Optional helper programs still need their own runtimes or configured services. Read the [capability contract](shared/router/references/capabilities.md) before using them. Live CLI verification needs authenticated providers and consumes model usage. Hash checks establish integrity against the reviewed inputs, not the authenticity of an arbitrary download.

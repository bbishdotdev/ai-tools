# bstack

![bstack works with Claude Code, Codex, Cursor, OpenCode, and GitHub Copilot in their CLIs and desktop apps, and with Grok and Amp in their CLIs](assets/supported-tools.svg)

bstack is an opinionated suite of skills, agents, and tools for planning, building, and reviewing software with AI coding agents. This folder is the complete package, version 3.5.1. It installs into a project from these files alone, with no downloads, and works the same way across the tools above.

It builds on [Lauren "poteto" Tan's PStack](https://github.com/cursor/plugins/tree/main/pstack) and [Matt Pocock's skills](https://github.com/mattpocock/skills). Some workflows reuse their work directly and others adapt it. [Attribution](ATTRIBUTION.md) records what comes from where.

## What bstack does

![Plan, build, and review with connected handoffs, architecture decisions, shared memory, and a local workspace](assets/workflow.svg)

- **Plan.** `grill-me` and `wayfinder` question a plan until the unknowns are settled. `to-spec` and `to-tickets` turn accepted scope into work. A local workspace app holds the maps, decisions, specs, and Kanban tickets, with no external tracker.
- **Build.** `poteto-mode` picks an engineering workflow for the task: bug fix, feature, investigation, or performance work. `how` and `why` explain existing code, `architect` and `prototype` compare designs, and `implement` builds approved work. A project verifier can drive the real app to check the result.
- **Review.** `to-pr` writes a short visual PR briefing and checks open PRs for overlap. `review-pr` runs two independent model reviewers and an adjudicator. `resolve-pr` works through feedback on your own PR. A committed project policy sets what needs a human.
- **Keep context.** Handoffs carry work between sessions, the ADR process records the few decisions worth keeping, and optional shared memory follows you across tools.

Setup also adds a seven-rule [baseline](shared/references/baseline-agents.md) to the project's agent instructions. Each skill loads only what its task needs; the collection is not inserted into every prompt.

Skills are grouped under `engineering/`, `sdlc/` for planning, and `shared/` for controls and writing. Principles and playbooks stay internal and load on demand. For package contents, installation effects, and network behavior, read the [security overview](SECURITY.md).

## Tool compatibility

![bstack compatibility across skills, auto mode, PR workflows, and hooks for CLI and desktop tools](assets/compatibility.svg)

Partial means a known gap or pending live validation; not supported means no bstack binding yet. These statuses describe bstack integration, not every feature of the host itself.

## Install

Python 3.11+ on macOS or Linux is required. Folder and archive routes install the same bundled package.

Setup adds the seven-rule [baseline](shared/references/baseline-agents.md) directly to a managed block in `AGENTS.md`. When Claude is selected and the project has no `CLAUDE.md`, setup creates one that only imports `AGENTS.md`, so the baseline lives in one place. An existing `CLAUDE.md`, and one from an earlier BStack install, gets the managed block. Setup preserves existing project text and shared symlinks. The baseline applies with auto mode off. Add project-specific guidance outside the blocks; native tool init is optional and never runs automatically. Run `doctor` after an init to detect changed or missing blocks. Updates and uninstall touch only the owned blocks.

### Use this complete folder

This folder is also the `bstack` installer skill. Copy it intact into a skill catalog, install that one entry, then invoke `/bstack` or `$bstack` in the target project. It needs no ZIP. Bundled workflow bodies use `INSTRUCTIONS.md`, leaving only the root `SKILL.md` visible to recursive discovery. Setup creates the public skill entries after it owns the installed package.

```sh
python3.12 /path/to/bstack/scripts/bstack.py install --project /path/to/project
python3.12 /path/to/project/.bstack/package/scripts/bstack.py doctor --project /path/to/project
```

Choose any available Python 3.11+ interpreter. Setup validates and saves that exact executable for hooks; later status and mode changes preserve it. If it disappears, rerun setup with a supported interpreter. Doctor checks owned files before probing actual command startup, and keeps native trust and delivery separate.

Each checkout gets its own `.bstack/package/` and bindings. The distributor keeps its original folder; removing it does not break the installed copy. Setup reports both locations and the package manifest hash. Commit portable project instructions, `.gitignore`, and a new PR template as appropriate. The `.bstack/` ignore block stays stable; a separate shared-policy block holds narrow generated-path rules and preserves visibility exceptions. Review `sharing` for mixed settings and visible or tracked generated paths. Doctor reports policy maintenance without changing files or treating it as broken bindings. Uninstall preserves shared ignore policy for the team to revise; ignores do not hide tracked edits.

Claude uses portable commands in `.claude/settings.local.json` backed by private launch scripts for this checkout. Only owned hooks migrate from the older shared settings destination. Start a fresh native session in the target checkout, including worktrees; switching worktrees inside an existing Claude session is not part of this guarantee.

### With skills.sh

From the project where you want to use bstack, run:

```sh
npx skills add bbishdotdev/ai-tools --skill install-bstack
```

Choose your agent and project scope if prompted. Then open your agent in that project and ask:

> Use install-bstack to set up this project for my installed tools.

skills.sh downloads the installer skill; your agent runs it to install the full bundled package and check the result. Keep both the repository name and `--skill install-bstack` in the command. You don't need to select individual engineering or SDLC skills. New installs enable automatic engineering routing; upgrades preserve the project's existing setting.

### From a download or clone

[Download bstack](https://github.com/bbishdotdev/ai-tools/releases/latest), choose `bstack-<version>.zip`, and extract it. Ask your agent to read `SKILL.md` in the extracted folder and install bstack into your project. Or run there:

```sh
python3 install.py --project /path/to/my-project
```

From a clone or source archive, the same entrypoint is `bstack/release/skills-sh/install-bstack/install.py`. It installs the bundled package and runs `doctor` without Git, npm, skills.sh, or network access. Add `--hosts` followed by the tools you want to choose hosts, including optional `amp`, `copilot`, or `opencode`. Without it, a new install configures Codex, Claude Code, Cursor, and Grok; an upgrade preserves the existing selection. Amp, Copilot, and OpenCode use native routing and PR-guard bindings. See the [compatibility matrix](assets/compatibility.svg) for recorded support and limits.

If you already have this unpacked runtime package, its controller also supports direct installation:

```sh
python3 <package-path>/scripts/bstack.py install --project <project-root>
python3 <project-root>/.bstack/package/scripts/bstack.py doctor --project <project-root>
```

Installation creates `.bstack/package/` and direct public entries in `.agents/skills/`. Claude Code, Cursor, and Grok get host-specific links; Amp, Copilot, and OpenCode use the shared entries directly. The original source can be removed afterward.

Install into each Git repo where the agent will work. A BStack install in a parent workspace does not automatically bind child repos. For Claude Code, parent instructions may load without the child's skill links or auto hook. A globally available `install-bstack` skill can install this exact bundled package into each repo; then run that repo's `doctor` and start a fresh Code chat. To use a parent package as the source, run its controller's `setup --project <child-repo>` and then use the child package's controller for `auto` and `doctor`.

A skills.sh distributor uses the separate `install-bstack` transport skill, whose archive contains this same package. Run that skill's installer after distribution. skills.sh does not run setup automatically.

## Choose a workflow

Start where the work is. Ask "How do I use bstack?" or invoke `bstack-guide` for a short walkthrough. Its [offline visual guide](shared/bstack-guide/assets/overview.html) has a searchable catalog, Cmd/Ctrl+K palette, and manual-versus-auto routing explainer. Use `how` or `why` to understand code, `bro` to restate the last answer plainly, `poteto-mode` to select an engineering workflow, `grill-me` or `wayfinder` to explore a plan, `prototype` to compare designs, `to-spec` and `to-tickets` to organize accepted work, and `implement` when the request is ready to build. The PR entries are `to-pr`, `review-pr`, and `resolve-pr`. No full sequence is required.

Some workflows need more than the host running your chat. [review-pr](engineering/review-pr/INSTRUCTIONS.md), for example, currently calls authenticated GitHub, Codex, and Claude Code CLIs for its model-backed run. Installing bstack does not sign in to those services. Reviewers search the whole pinned repository, including unchanged callers, with each CLI's own read-only tools. Static review needs no MCP server, OS worker, or system packages. BStack does not sandbox the reviewer CLIs; optional app and test execution requires a separate credential-free runtime worker. See [review setup](engineering/review-pr/references/running.md).

Invoke a public skill with the host's command prefix. Codex uses `$how`; slash-command hosts use `/how`. Use `poteto-mode` when you want the router to select a complete engineering workflow. The [index](index.json) resolves internal dependencies; the [manifest](manifest.json) lists public skills and exact installed files.

The baseline and package pointer live in project instructions. Public discovery entries point the agent to bundled instructions, which call for only the dependencies the task needs. A small set of skills, including `triage`, `prototype`, and the PR entries, can be discovered from ordinary requests; the rest stay explicitly invoked or routed. `bstack-guide` can answer questions about using the stack. The customized [unslop](shared/unslop/INSTRUCTIONS.md) remains active for prose. `bstack-auto on`, `off`, and `status` control automatic engineering routing with the host's skill prefix. Auto hooks carry a short router reminder, not the whole skill corpus. A bare invocation shows the mode choices without changing anything. The same commands are available from the controller:

```sh
python3 <project-root>/.bstack/package/scripts/bstack.py auto on --project <project-root>
python3 <project-root>/.bstack/package/scripts/bstack.py doctor --project <project-root>
```

Start a fresh session after bindings change. Checking status or repeating an unchanged mode does not require a new session. Turning auto off cannot erase existing conversation context. Amp, Copilot, and OpenCode use native adapters over the same shared router reminder when auto is on. Their native trust and plugin settings still apply.

For Codex, open `codex` in a terminal in the project directory and enter `/hooks` there to review hook trust. `/hooks` is not a desktop chat command. Setup does not grant or inspect trust, and `auto status` confirms configuration only. A PR creation guard stays bound for every selected host even when routing is manual. Its installed binding and a recorded native denial are separate checks. If Codex hooks are explicitly disabled, manual setup can complete but that guard cannot run there; automatic Codex routing requires hooks. Cursor and Grok's after-tool reminders do not guarantee first-tool or tool-free delivery. CLI packaging does not establish desktop or native plugin-manager support.

## Local planning and tickets

```sh
python3 <package-path>/workspace/cli.py --project <project-root> init
python3 <package-path>/workspace/cli.py --project <project-root> serve
```

Open the printed local URL. Work stays in the owning Git project's ignored `.bstack/workspace/`; linked worktrees share the same store. The browser and agent CLI use the same records. See [workspace use](workspace/README.md) and [operations](workspace/OPERATIONS.md). Python and Git are required for the workspace; Node and network access are not required to run the compiled app.

Use `wayfinder` to organize unknowns, `to-spec` for accepted scope, and `to-tickets` for implementation slices. Known small work can start with a ticket. Planning does not start implementation. The `implement` entry revalidates approved work before entering the engineering process. `handoff` preserves current record revisions, authority and artifacts for a fresh session, including prototype-to-implementation transitions.

Manual planning needs no model setup. Grilling models can be configured and checked for later while work stays human-guided. An autonomous interview requires two distinct available models and explicit delegation for the task; see [decision authority](shared/references/decision-authority.md). `review-pr` uses two independent model reviewers and a third adjudicator; its defaults require authenticated Claude Code and Codex CLIs. Setup shows the effective model choices and efforts before offering to keep or change them. Grilling has no default model pair. Neither optional workflow blocks basic installation. Wayfinder and tickets have [independent provider selections](shared/references/work-adapters.md). Both default to local. Jira, GitHub and Linear adapters remain future work; unsupported configured providers are reported without silent fallback.

## Project verification

New installs use `verification ask`: for a feature or bug that changes a user path, BStack proposes a focused change to the project's `verify-<app>` skill and waits for your answer. `verification auto` maintains the affected path during authorized work; `verification off` leaves the verifier alone unless you request it. Normal tests still run in every mode. Read the [verification policy](shared/references/verification-policy.md), or change the mode with the installed controller:

```sh
python3 <project-root>/.bstack/package/scripts/bstack.py verification status --project <project-root>
python3 <project-root>/.bstack/package/scripts/bstack.py verification auto --project <project-root>
```

Upgrades keep the existing setting. A full verifier audit is a separate explicit task, not something every code change triggers.

## Pull requests

Use [to-pr](engineering/to-pr/INSTRUCTIONS.md) for authorized PR delivery. It reuses the completed implementation and review, produces a short visual briefing, and checks all open work for duplicate or conflicting intent. Flagged or incomplete reviews publish as drafts with linked notices.

Use [review-pr](engineering/review-pr/INSTRUCTIONS.md) for an independent assessment. Use [resolve-pr](engineering/resolve-pr/INSTRUCTIONS.md) on the author's side to check feedback before fixing or replying. It limits changes to the PR's purpose and keeps unrelated suggestions separate.

For project-specific priorities, invoke [configure-pr](shared/configure-pr/INSTRUCTIONS.md). It maintains an optional committed `bstack-pr-policy.md` at the Git repo root. All three PR workflows use its human-review paths, critical behavior, focus areas and linked standards alongside the shared [PR standards](shared/references/pr-standards.md). Setup does not create an empty policy in consuming projects.

The [template](github/pull_request_template.md) and [Python helper](github/pr.py) ship here. Setup copies the template to `.github/pull_request_template.md` when the project has no PR template. That copy belongs to the project: edit it freely, and upgrades or uninstall will leave it alone. Existing templates in the root, `docs`, or `.github` take precedence. Setup reports every existing location and leaves those files untouched. To switch, compare the bundled template with the existing file, save the old contents, and replace the specific file you choose. For a multi-template directory, choose a file to replace or add BStack as a named option. Commit the chosen template to the default branch for GitHub to show it in the PR form. The helper uses authenticated `gh` for pushed branches within the same GitHub repository. It prepares locally, checks freshness, and writes only with explicit `publish --write`. PR-only images try `gh pr edit --attach` first. If upload fails, use the authored diagram fallback and keep a non-micro PR draft until it has a useful visual. Committing an image just to host it requires the user's approval. Other forges need a supported adapter; GitHub PR publishing does not implement the planning or ticket tracker adapters.

## Optional shared memory

Ask your agent: "Use setup-bstack to enable shared personal memory on this machine."

The [memory setup guide](shared/memory/references/installation.md) covers preview, activation, and existing installations. The commands are:

```sh
python3 <package-path>/scripts/bstack.py memory setup
python3 <package-path>/scripts/bstack.py memory setup --apply-plan <digest>
python3 <package-path>/scripts/bstack.py memory status
```

The first command only previews. Setup copies the reviewed runtime to `~/.local/share/bstack/memory/runtime/` and connects Codex, Claude, and Cursor's file bridge. The user-wide skill at `~/.agents/skills/memory-policy` owns later approved note operations. This private payload is not another project-level skill. Grok has no memory adapter.

Project setup and auto mode do not activate memory. Existing notes and unrelated configuration survive setup. Legacy source-linked memory installs are reported and left untouched. Setup status checks files and configuration; fresh-session recall needs a separate live check.

## Update and remove

Get a newer installer first. With skills.sh, rerun `npx skills add bbishdotdev/ai-tools --skill install-bstack` or the tagged command you chose, adding `-g` again for a user-scoped installer. Then ask your agent to use `install-bstack` to upgrade this project. From a newer release ZIP or clone, run its `install.py --project <project-root>`. Updating the installer skill alone does not update this package. Stop workspace servers and writers before upgrading the local app.

The installer preserves the chosen mode and hosts, checks owned files, and refuses unowned or changed content. Check its `doctor` result and start a fresh session when requested. Existing offline Poteto Mode bundles migrate to the package layout. Old third-party distributor entries must be resolved through their owner if they collide.

Run the canonical controller with `uninstall --project <project-root>` to remove its verified package and owned bindings. Private work, workspace databases, role and adapter configuration, artifacts, and separately distributed installer skills are preserved. Install separately per checkout; generated absolute bindings are machine-specific.

User memory has a separate lifetime. Project updates and removal leave its runtime and notes intact. Explicitly rerun memory setup from a reviewed newer bundle to update that runtime.

## Dependencies and source

[Attribution and required notices](ATTRIBUTION.md) travel with the package. The manifest records source hashes and build transformations. [layers.json](layers.json) records the active replacements. Installation never follows upstream latest.

Optional helper programs still need their own runtimes or configured services. Read the [capability contract](shared/router/references/capabilities.md) before using them. Live CLI verification needs authenticated providers and consumes model usage. Hash checks establish integrity against the reviewed inputs, not the authenticity of an arbitrary download.

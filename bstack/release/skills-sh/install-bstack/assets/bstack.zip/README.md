# bstack

Version 2.1.0-dev.1. bstack is the collection; Poteto Mode is one engineering skill within it. The package groups public engineering skills under `engineering/`, planning skills under `sdlc/`, and shared controls and writing skills under `shared/`. Principles and playbooks stay internal and load only when needed.

The local workspace app supports Wayfinder maps, accepted decisions, specs and Kanban tickets. The PR workflow provides a visual briefing, final overlap review, and optional GitHub publishing. Optional shared memory installs a separate user runtime from this bundle.

## Install

Python 3.11+ on macOS or Linux is required. Both routes install the same bundled package.

Setup adds the seven-rule [baseline](shared/references/baseline-agents.md) directly to managed blocks in `AGENTS.md` and, when Claude is selected, `CLAUDE.md`. It creates missing files and preserves existing project text and shared symlinks. The baseline applies with auto mode off. Add project-specific guidance outside the blocks; native tool init is optional and never runs automatically. Run `doctor` after an init to detect changed or missing blocks. Updates and uninstall touch only the owned blocks.

### With skills.sh

From the project where you want to use bstack, run:

```sh
npx skills add bbishdotdev/ai-tools --skill install-bstack
```

Choose your agent and project scope if prompted. Then open your agent in that project and ask:

> Use install-bstack to set up this project for my installed tools.

skills.sh downloads the installer skill; your agent runs it to install the full bundled package and check the result. Keep both the repository name and `--skill install-bstack` in the command. You don't need to select individual engineering or SDLC skills. New installs enable automatic engineering routing; upgrades preserve the project's existing setting.

### From a download or clone

[Download bstack](https://github.com/bbishdotdev/ai-tools/releases/latest), choose `bstack-<version>.zip`, and extract it. Ask your agent to read `SKILL.md` in the extracted folder and install bstack into your project. Or run there:

```sh
python3 install.py --project /path/to/my-project
```

From a clone or source archive, the same entrypoint is `bstack/release/skills-sh/install-bstack/install.py`. It installs the bundled package and runs `doctor` without Git, npm, skills.sh, or network access. Add `--hosts` followed by the tools you want to choose hosts, including optional `amp` or `copilot`. Without it, a new install configures Codex, Claude Code, Cursor, and Grok; an upgrade preserves the existing selection. Amp and Copilot currently discover skills and project instructions, but have no BStack hook binding.

If you already have this unpacked runtime package, its controller also supports direct installation:

```sh
python3 <package-path>/scripts/bstack.py install --project <project-root>
python3 <project-root>/.bstack/package/scripts/bstack.py doctor --project <project-root>
```

Installation creates `.bstack/package/` and direct public entries in `.agents/skills/`. Claude Code, Cursor, and Grok get host-specific links; Amp and Copilot use the shared entries directly. The original source can be removed afterward.

Install into each Git repo where the agent will work. A BStack install in a parent workspace does not automatically bind child repos. For Claude Code, parent instructions may load without the child's skill links or auto hook. A globally available `install-bstack` skill can install this exact bundled package into each repo; then run that repo's `doctor` and start a fresh Code chat. To use a parent package as the source, run its controller's `setup --project <child-repo>` and then use the child package's controller for `auto` and `doctor`.

A skills.sh distributor uses the separate `install-bstack` transport skill, whose archive contains this same package. Run that skill's installer after distribution. skills.sh does not run setup automatically.

## Choose a workflow

Start where the work is. Ask "How do I use bstack?" or invoke `bstack-guide` for a short walkthrough. Its [offline visual guide](shared/bstack-guide/assets/overview.html) has a searchable catalog, Cmd/Ctrl+K palette, and manual-versus-auto routing explainer. Use `how` or `why` to understand code, `bro` to restate the last answer plainly, `poteto-mode` to select an engineering workflow, `grill-me` or `wayfinder` to explore a plan, `prototype` to compare designs, `to-spec` and `to-tickets` to organize accepted work, and `implement` when the request is ready to build. The PR entries are `to-pr`, `review-pr`, and `resolve-pr`. No full sequence is required.

Some workflows need more than the host running your chat. [review-pr](engineering/review-pr/SKILL.md), for example, currently calls authenticated GitHub, Codex, and Claude Code CLIs for its model-backed run. Installing bstack does not sign in to those services.

Invoke a public skill with the host's command prefix. Codex uses `$how`; slash-command hosts use `/how`. Use `poteto-mode` when you want the router to select a complete engineering workflow. The [index](index.json) resolves internal dependencies; the [manifest](manifest.json) lists public skills and exact installed files.

The baseline and package pointer live in project instructions. Public discovery entries point the agent to bundled instructions, which call for only the dependencies the task needs. A small set of skills, including `triage`, `prototype`, and the PR entries, can be discovered from ordinary requests; the rest stay explicitly invoked or routed. `bstack-guide` can answer questions about using the stack. The customized [unslop](shared/unslop/SKILL.md) remains active for prose. `bstack-auto on`, `off`, and `status` control automatic engineering routing with the host's skill prefix. Auto hooks carry a short router reminder, not the whole skill corpus. A bare invocation shows the mode choices without changing anything. The same commands are available from the controller:

```sh
python3 <project-root>/.bstack/package/scripts/bstack.py auto on --project <project-root>
python3 <project-root>/.bstack/package/scripts/bstack.py doctor --project <project-root>
```

Start a fresh session after bindings change. Checking status or repeating an unchanged mode does not require a new session. Turning auto off cannot erase existing conversation context. Amp and Copilot can read the project router instruction when auto is on, but no BStack hook refreshes it per turn in those hosts.

For Codex, open `codex` in a terminal in the project directory and enter `/hooks` there to review hook trust. `/hooks` is not a desktop chat command. Setup does not grant or inspect trust, and `auto status` confirms configuration only. A PR creation guard stays bound for selected Codex, Claude Code, Cursor, and Grok hosts even when routing is manual. Amp and Copilot have no BStack guard. If Codex hooks are explicitly disabled, manual setup can complete but that guard cannot run there; automatic Codex routing requires hooks. Cursor and Grok's after-tool reminders do not guarantee first-tool or tool-free delivery. CLI packaging does not establish desktop or native plugin-manager support.

## Local planning and tickets

```sh
python3 <package-path>/workspace/cli.py --project <project-root> init
python3 <package-path>/workspace/cli.py --project <project-root> serve
```

Open the printed local URL. Work stays in the owning Git project's ignored `.bstack/workspace/`; linked worktrees share the same store. The browser and agent CLI use the same records. See [workspace use](workspace/README.md) and [operations](workspace/OPERATIONS.md). Python and Git are required for the workspace; Node and network access are not required to run the compiled app.

Use `wayfinder` to organize unknowns, `to-spec` for accepted scope, and `to-tickets` for implementation slices. Known small work can start with a ticket. Planning does not start implementation. The `implement` entry revalidates approved work before entering the engineering process. `handoff` preserves current record revisions, authority and artifacts for a fresh session, including prototype-to-implementation transitions.

Manual planning needs no model setup. Explicit autonomous grilling requires two distinct configured models and evidence that the host can run them; see [decision authority](shared/references/decision-authority.md). `review-pr` uses two independent model reviewers and a third adjudicator; its defaults require authenticated Claude Code and Codex CLIs. Neither optional workflow blocks setup. At first use, the agent should explain the roles, check available tools, and ask for model choices only when a default cannot run. Wayfinder and tickets have [independent provider selections](shared/references/work-adapters.md). Both default to local. Jira, GitHub and Linear adapters remain future work; unsupported configured providers are reported without silent fallback.

## Project verification

New installs use `verification ask`: for a feature or bug that changes a user path, BStack proposes a focused change to the project's `verify-<app>` skill and waits for your answer. `verification auto` maintains the affected path during authorized work; `verification off` leaves the verifier alone unless you request it. Normal tests still run in every mode. Read the [verification policy](shared/references/verification-policy.md), or change the mode with the installed controller:

```sh
python3 <project-root>/.bstack/package/scripts/bstack.py verification status --project <project-root>
python3 <project-root>/.bstack/package/scripts/bstack.py verification auto --project <project-root>
```

Upgrades keep the existing setting. A full verifier audit is a separate explicit task, not something every code change triggers.

## Pull requests

Use [to-pr](engineering/to-pr/SKILL.md) for authorized PR delivery. It reuses the completed implementation and review, produces a short visual briefing, and checks all open work for duplicate or conflicting intent. Flagged or incomplete reviews publish as drafts with linked notices.

Use [review-pr](engineering/review-pr/SKILL.md) for an independent assessment. Use [resolve-pr](engineering/resolve-pr/SKILL.md) on the author's side to check feedback before fixing or replying. It limits changes to the PR's purpose and keeps unrelated suggestions separate.

For project-specific priorities, invoke [configure-pr](shared/configure-pr/SKILL.md). It maintains an optional committed `bstack-pr-policy.md` at the Git repo root. All three PR workflows use its human-review paths, critical behavior, focus areas and linked standards alongside the shared [PR standards](shared/references/pr-standards.md). Setup does not create an empty policy in consuming projects.

The [template](github/pull_request_template.md) and [Python helper](github/pr.py) ship here. Setup copies the template to `.github/pull_request_template.md` when the project has no PR template. That copy belongs to the project: edit it freely, and upgrades or uninstall will leave it alone. Existing templates in the root, `docs`, or `.github` take precedence. Setup reports every existing location and leaves those files untouched. To switch, compare the bundled template with the existing file, save the old contents, and replace the specific file you choose. For a multi-template directory, choose a file to replace or add BStack as a named option. Commit the chosen template to the default branch for GitHub to show it in the PR form. The helper uses authenticated `gh` for pushed branches within the same GitHub repository. It prepares locally, checks freshness, and writes only with explicit `publish --write`. Media upload falls back to the authored Mermaid, table, or text explanation. Other forges need a supported adapter; GitHub PR publishing does not implement the planning or ticket tracker adapters.

## Optional shared memory

Ask your agent: "Use setup-bstack to enable shared personal memory on this machine."

The [memory setup guide](shared/memory/references/installation.md) covers preview, activation, and existing installations. The commands are:

```sh
python3 <package-path>/scripts/bstack.py memory setup
python3 <package-path>/scripts/bstack.py memory setup --apply-plan <digest>
python3 <package-path>/scripts/bstack.py memory status
```

The first command only previews. Setup copies the reviewed runtime to `~/.local/share/bstack/memory/runtime/` and connects Codex, Claude, and Cursor's file bridge. The user-wide skill at `~/.agents/skills/memory-policy` owns later approved note operations. This private payload is not another project-level skill. Grok has no memory adapter.

Project setup and auto mode do not activate memory. Existing notes and unrelated configuration survive setup. Legacy source-linked memory installs are reported and left untouched. Setup status checks files and configuration; fresh-session recall needs a separate live check.

## Update and remove

Get a newer installer first. With skills.sh, rerun `npx skills add bbishdotdev/ai-tools --skill install-bstack` or the tagged command you chose, adding `-g` again for a user-scoped installer. Then ask your agent to use `install-bstack` to upgrade this project. From a newer release ZIP or clone, run its `install.py --project <project-root>`. Updating the installer skill alone does not update this package. Stop workspace servers and writers before upgrading the local app.

The installer preserves the chosen mode and hosts, checks owned files, and refuses unowned or changed content. Check its `doctor` result and start a fresh session when requested. Existing offline Poteto Mode bundles migrate to the package layout. Old third-party distributor entries must be resolved through their owner if they collide.

Run the canonical controller with `uninstall --project <project-root>` to remove its verified package and owned bindings. Private work, workspace databases, role and adapter configuration, artifacts, and separately distributed installer skills are preserved. Install separately per checkout; generated absolute bindings are machine-specific.

User memory has a separate lifetime. Project updates and removal leave its runtime and notes intact. Explicitly rerun memory setup from a reviewed newer bundle to update that runtime.

## Dependencies and source

[Attribution and required notices](ATTRIBUTION.md) travel with the package. The manifest records source hashes and build transformations. [layers.json](layers.json) records the active replacements. Installation never follows upstream latest.

Optional helper programs still need their own runtimes or configured services. Read the [capability contract](shared/router/references/capabilities.md) before using them. Live CLI verification needs authenticated providers and consumes model usage. Hash checks establish integrity against the reviewed inputs, not the authenticity of an arbitrary download.

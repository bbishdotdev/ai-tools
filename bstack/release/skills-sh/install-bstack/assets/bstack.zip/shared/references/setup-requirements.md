# Setup when a workflow needs it

BStack's local planning, tickets, basic engineering skills, and manual grilling do not need a model-role picker or an external tracker. Install the package, select the agent hosts you use, and start a fresh agent session so its skill catalog refreshes. New installs enable automatic routing; upgrades keep the previous choice. `bstack-auto off` leaves named skills available.

Check a requirement only when the requested workflow reaches it. Explain what the missing tool does, why this step needs it, and the smallest way to proceed. Do not ask someone to configure every optional integration during installation.

| When you do this | What you need | If it is missing |
| --- | --- | --- |
| Use local Wayfinder, specs, or tickets | A writable project directory and Python 3 | Report the local filesystem or Python problem. No Jira, Linear, or GitHub account is needed. |
| Publish, edit, review, or resolve a GitHub PR | A Git remote, an authenticated `gh` CLI, and access to that PR | Keep local preparation or feedback; explain that posting to GitHub is unavailable. Do not pretend a local comment was published. |
| Run `review-pr` with independent reviewers | The configured, authenticated reviewer CLIs and a usable model for each role | Run `bstack.py doctor --live --workflow review-pr`. The review runner repeats the short checks before a new review and stops on a broken role. Two prompts to the same model are not independent model-family review. |
| Run autonomous grilling | Two distinct accessible model participants configured through `shared/workflow.py configure-grilling` | Run `bstack.py doctor --live --workflow grilling` before planning writes. Continue with human-guided grilling if a role cannot answer. Native host participants still need a host-level check; the CLI doctor cannot certify them. |
| Ask `to-pr` to generate an image through Codex | A permitted, authenticated Codex launcher | Run `bstack.py doctor --live --workflow to-pr` before the visual attempt. This checks a text prompt, not image-tool access; inspect the actual visual and use the documented fallback if the image tool is unavailable. |
| Use an imported multi-model engineering workflow such as Arena or Interrogate | A host-supported way to delegate and models accessible on that host | Inherit the parent's model for an ordinary delegate when appropriate. State clearly if independent-model comparison could not happen. Ignore upstream Cursor model files and fixed provider names. |
| Run an imported helper | Its documented local runtime and any specific service it uses | Check the helper before use. Do not install Bun, Graphite, Tailscale, or a cloud service just because a pinned source mentions it. |
| Create or maintain a project verifier | A real app path to exercise and the project's verification setting | `off` skips verifier edits, `ask` proposes a concrete change, and `auto` maintains the affected recipe. If the app cannot run, record the limit and run the available checks. |

The `quarantined_playbooks` in the installed `index.json` are not active. Their pinned files document upstream behavior; they do not become portable because the bundle contains them. Do not run the bundled watcher, cleanup, cloud, or orchestration helpers through a fallback guess. Offer a supported narrower workflow and state which capability would have to be ported.

Host hook setup differs. Claude Code, Cursor, and Grok can load their configured project hooks in a fresh session. Codex requires hook support to be enabled and local hook trust to be reviewed. A passing package `doctor` check confirms installed files and bindings, not live hook delivery, model access, or a full workflow run. Run the relevant live verification before claiming those behaviors work.

For a wrapped CLI, use `python3 .bstack/package/shared/model_cli.py --project "$PWD" configure --cli claude --command 'launch claude -- {args}'`, replacing the command with the developer's real launcher. The `{args}` slot is required; BStack inserts the native CLI arguments there without a shell. This private setting applies to model probes, PR reviews and Codex PR visuals. Run the selected workflow's live doctor after changing it. Ordinary setup stays usable when an optional model workflow is unavailable.

# Run a review

Requires Python 3.11+, Git, authenticated `gh` for the PR's host, and the selected model CLIs on macOS or Linux. The first draft implements Claude Code and Codex runners; its process and file locking require a POSIX host. It can be invoked from another agent host, but Cursor and Grok are not yet review execution adapters. No Wayfinder workspace, tracker, or skills.sh connection is required.

Static review needs no OS worker or extra system packages. BStack starts its bundled repository browser for each headless session and connects it privately to the selected CLI. It adds no global MCP configuration or listening network service. Reviewers can list, search, read, and compare the full pinned repository, including unchanged callers. BStack handles these requests automatically without file-read approvals.

General machine tools are disabled at the model interface: no shell, arbitrary filesystem reader, browser, or unrelated integration. Codex may use its pure V8 orchestration tool to call the repository browser; that tool has no host filesystem or network APIs. Run `doctor --live` to check the restricted launches and actual model logins. If an installed CLI cannot support the required restrictions, repair or update that CLI rather than restoring general tools. Custom launchers use the shared configuration below.

## Roles

Defaults are Opus 5.5 at medium effort, Codex Astra at medium effort, and a fresh Opus 5.5 adjudicator at high effort. Override only the roles you want in the project's private `.bstack/review.json`, or pass `--config /path/to/config.json` to the runner:

```json
{
  "roles": {
    "reviewer_a": {"cli": "claude", "model": "claude-opus-5-5", "effort": "medium"},
    "reviewer_b": {"cli": "codex", "model": "gpt-6-astra", "effort": "medium"},
    "adjudicator": {"cli": "claude", "model": "claude-opus-5-5", "effort": "high"}
  },
  "timeout_seconds": 900,
  "max_model_calls_24h": 60,
  "targets": ["github.com/owner/repo"]
}
```

`targets` is optional for a GitHub.com PR in the selected project's `origin` repository. Set it explicitly for another approved repository or GitHub host. The runner rejects other URLs before asking `gh` to contact them. This boundary follows `--project`, not the location of the BStack package, so a shared package can serve multiple projects without granting each review access to the others.

An optional `worker` argv wrapper can add OS isolation around the model CLIs. Static review does not require or automatically select one. A wrapper must preserve the private browser connection, review work directory, and absolute output paths. A script that merely forwards arguments is not isolation. BStack's restricted tools remain active inside a configured wrapper.

## Optional app or test execution

Static review inspects code, callers, tests, ADRs, and existing CI results. It does not execute the project's tests or application. To enable an existing project check, add a separate runtime configuration:

```json
{
  "runtime_verification": {
    "command": ["python3", "-B", "scripts/verify.py"],
    "worker": ["/absolute/path/to/no-network-runtime-worker", "{args}"],
    "timeout_seconds": 120
  }
}
```

`runtime_verification` is optional. It runs one fixed command from this private config against a disposable copy of the pinned PR head after the safety preflight passes. Point `command` at an existing, executable project check. The separate runtime worker must have no GitHub or model credentials, block network egress, and enforce CPU, memory, and process limits; do not use the review worker for this job. `doctor --live` probes its selected file, credential, environment, and host-loopback boundaries without running the project command. That probe cannot establish that every external route is blocked, so inspect the worker's actual network policy too. The snapshot has no `.git` directory or preinstalled dependencies. If the check needs either, provide the required trusted inputs inside the worker or leave runtime verification unconfigured; the runner will not retry on the host. Project output is hashed and bounded, never shown to the models as instructions. A failed or timed-out check leaves a reviewable partial assessment that cannot approve.

## Model checks and launchers

Two reviewers must use distinct model identities. Prefer different families for independent perspectives. The adjudicator may use either family in a fresh session. The safety preflight uses a configured Claude role with no tools, then the independent reviewers and adjudicator use their own restricted browsing sessions. Supported effort values are `low`, `medium`, and `high`; the configured model must support the requested value. Model IDs depend on the authenticated deployment. The runner does not substitute another model when one fails.

`doctor` checks configuration, executable availability, versions, and required CLI options. Add `--live` to ask each selected role to read a random snapshot value through the browser and try a traversal request that must be denied. The runner checks the answer and the browser trace. `run` does this before the three-model review. A failed role stops the run and names the role. A successful probe proves that browsing path worked at that moment; it cannot guarantee future login validity, independently confirm every CLI's effective model, or certify a launcher that silently drops restriction flags.

Before the first live check, reuse saved launch commands or commands already established in the session. Otherwise ask for the working headless terminal command for each required CLI, including any wrapper. Ask for command syntax only, never credentials or complete settings files. Save the executable and wrapper arguments in the project's private `.bstack/model-clis.json` through the bundled helper. For example, `python3 .bstack/package/shared/model_cli.py --project "$PWD" configure --cli claude --command 'launch claude -- {args}'`. BStack inserts its prompt, model and output arguments at `{args}` without a shell. Then run `python3 .bstack/package/scripts/bstack.py doctor --project "$PWD" --live --workflow review-pr`. The review runner uses the same command map. Do not guess flags or bypass the wrapper.

The installed CLI, wrapper, and administrator-managed policy are trusted local components. They must honor the supplied restrictions. Model authentication and permitted proxy settings still reach the CLI through the shared launcher; GitHub publication stays in the parent runner. Read [reviewer-job security](security.md) for these trust limits.

The roles are separate from autonomous grilling configuration. Changing review roles does not enable automatic routing or grant product/ADR decision authority.

## State and follow-ups

Run from the consumer's project and use its `.bstack/` directory for private review data. Run records include pinned source metadata, diffs, model responses, prior decisions, and publication state. Temporary source trees are removed when the run ends. Records can still contain private source code. Keep `.bstack/` gitignored.

The safety preflight runs tool-free with a reduced environment. Independent reviewers receive the repository browser and allowlisted BStack policy through `read_policy`; raw CLI output stays out of the public review. After an authentication failure, confirm whether the normal headless command works before diagnosing the login. If it works, BStack could not use that login; check its launch command and settings. Report the failed step without inferring logout or a certificate problem from a warning. The runner never replaces a failed reviewer with another model.

The runner pins the comparison tree, proposed head and current target tip. Reviewers can consult current target ADRs even when they landed after the PR forked. Only complete assessments become durable incremental baselines. A changed PR repeats the safety preflight, both reviewers, and the adjudicator on the affected delta, at most three passes total. A changed base/history or incomplete earlier coverage can require a full pass. A rebuttal or requirement change without new code produces a context reassessment. Reviewers decide which callers or contracts are affected.

Closed or merged PRs are skipped before models run. Confirmed merge conflicts defer review; unknown mergeability is not a confirmed conflict. Draft status and failing CI alone do not skip an explicitly requested review.

Unchanged assessments are reused, including saved partial assessments so the same missing evidence does not repeatedly spend model calls. Use `run --fresh` to request a new independent pass. Different role models or efforts also require a new pass. Review and preflight policy changes invalidate reuse, including old safety holds. Publishing a result made under an older policy stops with a request for a follow-up review. Run `review.py run` again before publishing. Timeout changes alone do not change the assessment.

Published reviews carry a bounded receipt for publication reconciliation. Another checkout does not use that receipt to skip model work or as its follow-up baseline, even if the GitHub account matches. Another developer's review remains discussion evidence. Receipt hashes are reproducible; they do not prove a model ran. A matching same-account review may still prevent posting the same assessment twice.

Changed CI results or public discussion can require a context refresh. Reactions and timestamps alone do not. Existing reviews remain visible to the models; only an assessment's own verified publication batch is excluded from its freshness comparison. Arbitrary new prose is conservatively reassessed rather than discarded by a keyword filter. Other open PRs are supplied as titles, descriptions and commit identities; titles alone cannot prove duplication.

The runner first checks the full pinned diff, PR description, and discussion for instructions aimed at controlling the reviewer. Ordinary hook registrations, scripts, network calls, and archives proceed to source review. Application behavior is not executed by the review models. Direct review-rule overrides in agent files and changed executable files that cannot be read as text still require human inspection. See [reviewer-job security](security.md#safety-preflight-and-publication) for the exact boundary.

A valid hold retains its explanations privately and prepares a comment with fixed descriptions of the attempted reviewer action and verified source links. Invalid evidence or missing explanations make the check incomplete; they do not produce a security comment or start reviewers. After a pass, reviewers explore captured source as data through the browser. A preflight pass does not permit executing PR code. Tool restrictions limit available actions but cannot prove every attack will be detected or every conclusion correct. Explicit model metadata is withheld from the judge; prose may still reveal stylistic clues.

The runner reserves one model call for preflight, then six more for live probes, reviewers, and adjudication if preflight passes. The default 24-hour budget is 60 calls; a fresh run or changed PR spends more. A PR diff above 640 KiB, preflight or review context above 768 KiB, or more than 1,000 changed paths stops before models run. The per-PR lock and local budget reduce duplicate callbacks and runaway model calls on one machine; they do not cap provider tokens or spend. A callback service must still verify GitHub's webhook signature, restrict its event types and target repositories, and deduplicate delivery IDs before starting this script. The runner does not provide a public webhook endpoint or a cross-machine rate limit.

The result schema is defined in [contracts.py](../scripts/contracts.py) and supplied to the model by the runner. Don't recreate the schema, anonymization, or GitHub calls in shell snippets. A valid schema proves structure, not that a finding is correct.

## Generated ZIPs

A generated ZIP can be covered through its reviewed source files when the runner proves that those files reproduce the exact archive. Configure the corresponding repository-relative paths in the private review configuration:

```json
{
  "zip_trees": {
    "dist/package.zip": "dist/package"
  }
}
```

The runner checks each existing base/head version against its own pinned source tree. Supported archives contain sorted regular UTF-8 files, Unix file modes, a fixed 1980 timestamp and deflate compression. It reconstructs bytes from that tree without extracting the supplied archive or executing project code. Exact matches produce source-equivalence evidence for the reviewers; they must still assess the source changes.

Unknown formats and non-text changes are assessed for material relevance. A changed image need not block unrelated code findings. A failed mapped archive verification remains an integrity gap; different compression-library output can prevent an exact match. Valid partial results retain findings and limits, but cannot approve or become the next complete baseline.

## Publication

`run` collects evidence and invokes models without posting. `publish --run ...` previews the actions; `--write` performs them within the user's authorization. If the PR moved, publication repeats preflight and the review on the changed delta within the three-pass limit and returns the new run path. Use the returned path for `--write`; the old path also resolves to its latest local follow-up when available. Agreement adds a thumbs-up, useful additions and disagreements reply in an existing inline thread, and responses to overall reviews use a short linked timeline comment. Resolved feedback links the earlier discussion and reviewed commit without repeating its evidence list. New findings are grouped by the action needed, with a short explanation, a separate next step, and named code links. Extra references are collapsed. A small signature names the models; it stays separate from the feedback.

Only unique new blockers cause a new request-changes event. Agreement with an existing blocker does not mean approval; it leaves the formal state alone. Complete assessments without blockers or unresolved human decisions may approve. Partial assessments can publish supported blockers or a comment explaining their limits. The runner never dismisses someone else's review or resolves their thread automatically.

When GitHub disallows a review event for the acting account, report the supported comment and intended verdict separately. An incomplete result cannot approve. If the PR moves again after three passes, the runner posts one comment-only review with the consolidated findings, the reviewed commit, and a clear warning that the latest changes were not checked. It does not approve, request changes, or issue reactions and thread replies from that stale snapshot. Required CI and repository merge policy remain separate from the model's judgment. The runner never merges a PR or changes branch protection.

Writes are recorded action by action. After an uncertain response, retry the same run so the runner can reconcile already-posted reactions, replies and reviews. Don't manually post the body again. If a PR changes after an action was sent, publication stops rather than starting a new review in the middle of that batch. A final freshness check reduces concurrent duplicates, but there is no cross-machine lock or guarantee of exactly-once model execution or publication.

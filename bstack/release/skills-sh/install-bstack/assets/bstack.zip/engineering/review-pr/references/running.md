# Run a review

Requires Python 3.11+, Git, authenticated `gh` for the PR's host, and the selected model CLIs on macOS or Linux. The first draft implements Claude Code and Codex runners; its process and file locking require a POSIX host. It can be invoked from another agent host, but Cursor and Grok are not yet review execution adapters. No Wayfinder workspace, tracker, or skills.sh connection is required.

## Roles

Defaults are Opus 5.5 at medium effort, Codex Astra at medium effort, and a fresh Opus 5.5 adjudicator at high effort. Override only the roles you want in the project's private `.bstack/review.json`, or pass `--config /path/to/config.json` to the runner:

```json
{
  "roles": {
    "reviewer_a": {"cli": "claude", "model": "claude-opus-5-5", "effort": "medium"},
    "reviewer_b": {"cli": "codex", "model": "gpt-6-astra", "effort": "medium"},
    "adjudicator": {"cli": "claude", "model": "claude-opus-5-5", "effort": "high"}
  },
  "timeout_seconds": 900,
  "max_model_calls_24h": 60,
  "targets": ["github.com/owner/repo"],
  "worker": ["/absolute/path/to/isolated-review-worker", "{args}"]
}
```

`targets` is optional for a GitHub.com PR in the project's `origin` repository. Set it explicitly for another approved repository or GitHub host. The runner rejects other URLs before asking `gh` to contact them. The worker is an argv wrapper around the selected model CLI. It must preserve the review work directory and absolute output paths while limiting readable files to that snapshot, the installed BStack package read-only, required CLI runtime, and narrowly scoped provider login. The package contains the review rules the model must read; when installed in a project, expose `.bstack/package` without exposing its sibling `.bstack/reviews` directory. Keep GitHub credentials and unrelated host files out, and restrict network access to the provider route it needs. A regular shell script that simply forwards arguments is not isolation.

The runner tests the worker by reading required BStack policy files, trying to read canaries outside the snapshot and in the project, probing common credential paths, and checking that `gh` cannot return a token inside the worker. It also checks access to a local listener when the host permits one. A passing canary is a useful check of the configured worker, not a proof that every host secret or network route is isolated. `doctor --live` also sends a short request through that worker. An untrusted PR cannot run without a configured worker. For a PR whose source you trust, `run --trusted-pr` explicitly permits the model CLIs to use their normal host access. Never put `--trusted-pr` in an automated callback.

Two reviewers must use distinct model identities. Prefer different families for independent perspectives. The adjudicator may use either family in a fresh session. Supported effort values are `low`, `medium`, and `high`; the configured model must support the requested value. Model IDs depend on the authenticated deployment. The runner does not substitute another model when one fails.

`doctor` checks configuration, executable availability, versions, and required CLI options. Add `--live` to check the worker canary and send one short prompt to each selected role. `run` does this before the three-model review. A failed role stops the run and names the role; BStack does not silently substitute a provider. A successful probe proves the CLI answered with the requested settings at that moment. It cannot guarantee the login will remain valid or, for every CLI, independently prove the exact effective model.

If the CLI runs through a local wrapper, configure its argument prefix once in the project's private `.bstack/model-clis.json` through the bundled helper. For example, `python3 .bstack/package/shared/model_cli.py --project "$PWD" configure --cli claude --command 'launch claude -- {args}'`. BStack expands `{args}` as an argument list, never as shell text. Then run `python3 .bstack/package/scripts/bstack.py doctor --project "$PWD" --live --workflow review-pr`. The same command map is used by the PR review runner. Ask the developer for the actual wrapper command when the normal invocation fails; do not guess flags or bypass the wrapper.

The roles are separate from autonomous grilling configuration. Changing review roles does not enable automatic routing or grant product/ADR decision authority.

## State and follow-ups

Run from the consumer's project and use its `.bstack/` directory for private review data. Run records include pinned source metadata, diffs, model responses, prior decisions, and publication state. Temporary source trees are removed when the run ends. Records can still contain private source code. Keep `.bstack/` gitignored.

Trusted-PR runs retain private model standard output, standard error and exit status to diagnose failures. Isolated-worker runs keep those raw streams out of the review record and return a short failure instead. Reauthenticate or repair the named CLI before retrying; the runner never replaces a failed reviewer with another model.

The runner pins the comparison tree, proposed head and current target tip. Reviewers can consult current target ADRs even when they landed after the PR forked. Only complete assessments become durable incremental baselines. With an isolated worker, a changed PR carries the earlier pass forward and repeats both reviewers and the adjudicator on the delta, at most three passes total. A host-access run granted with `--trusted-pr` instead stops when the code or discussion changes; explicitly start another trusted run for those inputs or configure a worker. A changed base/history or incomplete earlier coverage can require a full pass. A rebuttal or requirement change without new code produces a context reassessment. Reviewers decide which callers or contracts are affected.

Closed or merged PRs are skipped before models run. Confirmed merge conflicts defer review; unknown mergeability is not a confirmed conflict. Draft status and failing CI alone do not skip an explicitly requested review.

Unchanged assessments are reused, including saved partial assessments so the same missing evidence does not repeatedly spend model calls. Use `run --fresh` to request a new independent pass. Different role models or efforts also require a new pass. Timeout changes alone do not change the assessment.

Published reviews carry a bounded receipt for publication reconciliation. Another checkout does not use that receipt to skip model work or as its follow-up baseline, even if the GitHub account matches. Another developer's review remains discussion evidence. Receipt hashes are reproducible; they do not prove a model ran. A matching same-account review may still prevent posting the same assessment twice.

Changed CI results or public discussion can require a context refresh. Reactions and timestamps alone do not. Existing reviews remain visible to the models; only an assessment's own verified publication batch is excluded from its freshness comparison. Arbitrary new prose is conservatively reassessed rather than discarded by a keyword filter. Other open PRs are supplied as titles, descriptions and commit identities; titles alone cannot prove duplication.

Reviewers inspect materialized source as data. The runner disables supported host customization paths and restricts model tools; it does not run repository tests or hooks to establish behavior. Untrusted PRs require an external isolated worker, tested with a policy-file and outside-file canary. The publisher renders model prose as escaped plain text; only the runner creates clickable evidence links. This does not detect secrets written as ordinary prose, so the worker remains the primary boundary. Read [reviewer-job security](security.md) before running on a PR whose author may deliberately attack the reviewer host. Explicit model metadata is withheld from the judge; prose may still reveal stylistic clues.

The runner reserves six model calls per pass, including live probes, under a project-wide 24-hour budget before invoking them. The default is 60; a fresh run or changed PR spends more. A PR diff above 512 KiB, prompt context above 768 KiB, or more than 1,000 changed paths stops before models run. The per-PR lock and local budget reduce duplicate callbacks and runaway model calls on one machine; they do not cap provider tokens or spend. A callback service must still verify GitHub's webhook signature, restrict its event types and target repositories, and deduplicate delivery IDs before starting this script. The runner does not provide a public webhook endpoint or a cross-machine rate limit.

The result schema is defined in [contracts.py](../scripts/contracts.py) and supplied to the model by the runner. Don't recreate the schema, anonymization, or GitHub calls in shell snippets. A valid schema proves structure, not that a finding is correct.

## Generated ZIPs

A generated ZIP can be covered through its reviewed source files when the runner proves that those files reproduce the exact archive. Configure the corresponding repository-relative paths in the private review configuration:

```json
{
  "zip_trees": {
    "dist/package.zip": "dist/package"
  }
}
```

The runner checks each existing base/head version against its own pinned source tree. Supported archives contain sorted regular UTF-8 files, Unix file modes, a fixed 1980 timestamp and deflate compression. It reconstructs bytes from that tree without extracting the supplied archive or executing project code. Exact matches produce source-equivalence evidence for the reviewers; they must still assess the source changes.

Unknown formats and non-text changes are assessed for material relevance. A changed image need not block unrelated code findings. A failed mapped archive verification remains an integrity gap; different compression-library output can prevent an exact match. Valid partial results retain findings and limits, but cannot approve or become the next complete baseline.

## Publication

`run` collects evidence and invokes models without posting. `publish --run ...` previews the actions; `--write` performs them within the user's authorization. If the PR moved after an isolated-worker run, publication repeats the review on the changed delta within the three-pass limit and returns the new run path. A trusted host-access run requires a new explicit grant after code or discussion changes. Use the returned path for `--write`; the old path also resolves to its latest local follow-up when available. Agreement adds a thumbs-up, useful additions and disagreements reply in an existing inline thread, and responses to overall reviews use a short linked timeline comment. Resolved feedback links the earlier discussion and reviewed commit without repeating its evidence list. New findings appear in a concise review with category icons and the models that performed it.

Only unique new blockers cause a new request-changes event. Agreement with an existing blocker does not mean approval; it leaves the formal state alone. Complete assessments without blockers or unresolved human decisions may approve. Partial assessments can publish supported blockers or a comment explaining their limits. The runner never dismisses someone else's review or resolves their thread automatically.

When GitHub disallows a review event for the acting account, report the supported comment and intended verdict separately. An incomplete result cannot approve. If the PR moves again after three passes, the runner posts one comment-only review with the consolidated findings, the reviewed commit, and a clear warning that the latest changes were not checked. It does not approve, request changes, or issue reactions and thread replies from that stale snapshot. Required CI and repository merge policy remain separate from the model's judgment. The runner never merges a PR or changes branch protection.

Writes are recorded action by action. After an uncertain response, retry the same run so the runner can reconcile already-posted reactions, replies and reviews. Don't manually post the body again. If a PR changes after an action was sent, publication stops rather than starting a new review in the middle of that batch. A final freshness check reduces concurrent duplicates, but there is no cross-machine lock or guarantee of exactly-once model execution or publication.
